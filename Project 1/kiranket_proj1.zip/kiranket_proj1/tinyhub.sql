create database tinyhub;
use tinyhub;

CREATE TABLE IF NOT EXISTS user_account (
  email_id VARCHAR(45) NOT NULL,
  display_name VARCHAR(45) NOT NULL,
  password VARCHAR(45) NOT NULL,
  PRIMARY KEY (email_id),
  UNIQUE KEY unq_display_name (display_name)
);

CREATE TABLE IF NOT EXISTS department (
  department_id INT NOT NULL,
  department_name VARCHAR(45) NOT NULL,
  PRIMARY KEY (department_id)
  );
  
CREATE TABLE IF NOT EXISTS student (
   student_id VARCHAR(45) not null,
   department_id INT not null,
   course_id INT not null,
   semester_id int not null,
   PRIMARY KEY (student_id),
   FOREIGN KEY (student_id) REFERENCES user_account (email_id),
   FOREIGN KEY (department_id) REFERENCES department (department_id));
   -- FOREIGN KEY (course_id) REFERENCES course (course_id));
   
CREATE TABLE IF NOT EXISTS professor (
	professor_id VARCHAR(45) NOT NULL,
	department_id INT NOT NULL,
	course_id INT not null,
	PRIMARY KEY (professor_id),
	FOREIGN KEY (professor_id) REFERENCES user_account (email_id),
	CONSTRAINT FOREIGN KEY (department_id) REFERENCES department(department_id));
    
CREATE TABLE IF NOT EXISTS staff (
  staff_id VARCHAR(45) NOT NULL,
  staf_dept_id INT NOT NULL,
   FOREIGN KEY (staff_id) REFERENCES user_account (email_id),
   FOREIGN KEY (staf_dept_id) REFERENCES department(department_id));
   
CREATE TABLE IF NOT EXISTS majors_in (
  student_id VARCHAR(45) NOT NULL,
  department_id INT NOT NULL,
   PRIMARY KEY (student_id,department_id),
   FOREIGN KEY (student_id) REFERENCES student (student_id),
   FOREIGN KEY (department_id) REFERENCES department (department_id));
   
  CREATE TABLE IF NOT EXISTS hired (
  staff_id VARCHAR(45) NOT NULL,
  department_id INT NOT NULL,
  professor_id VARCHAR(45) NOT NULL,
   PRIMARY KEY (staff_id,department_id, professor_id),
   FOREIGN KEY (staff_id) REFERENCES staff (staff_id),
   FOREIGN KEY (department_id) REFERENCES department (department_id),
   FOREIGN KEY (professor_id) REFERENCES professor (professor_id));
   
 CREATE TABLE IF NOT EXISTS programs (
  program_id INT NOT NULL,
  department_id INT NOT NULL,
  program_name VARCHAR(45) NOT NULL,
   PRIMARY KEY(program_id),
	FOREIGN KEY (department_id) REFERENCES department (department_id)
);
   
CREATE TABLE IF NOT EXISTS course (
  course_id INT NOT NULL,
  department_id INT NOT NULL,
  course_name VARCHAR(45) NOT NULL,
  class_capacity INT NOT NULL,
   PRIMARY KEY(course_id),
   FOREIGN KEY (department_id) REFERENCES professor(department_id)
   );
   
   CREATE TABLE IF NOT EXISTS pursue (
   student_id VARCHAR(45) NOT NULL,
  program_id INT NOT NULL,
  department_id INT NOT NULL,
   PRIMARY KEY(student_id, program_id, department_id),
   FOREIGN KEY (student_id) REFERENCES student (student_id),
   FOREIGN KEY (program_id) REFERENCES programs (program_id),
   FOREIGN KEY (department_id) REFERENCES department (department_id)
   );
  
   CREATE TABLE IF NOT EXISTS exam (
  exam_id INT NOT NULL,
  course_id INT NOT NULL,
  student_id VARCHAR(45) NOT NULL,
  score INT NOT NULL,
  grade VARCHAR(2) NOT NULL,
   PRIMARY KEY(exam_id),
   FOREIGN KEY (course_id) REFERENCES course (course_id),
   FOREIGN KEY (student_id) REFERENCES student (student_id)
   );
   
   CREATE TABLE IF NOT EXISTS problems (
  problem_id INT NOT NULL,
  problem_data INT,
   exam_id INT NOT NULL,
   student_id VARCHAR(45) NOT NULL,
   PRIMARY KEY(problem_id),
   FOREIGN KEY (exam_id) REFERENCES exam (exam_id),
   FOREIGN KEY (student_id) REFERENCES student (student_id)
   );
   
CREATE TABLE IF NOT EXISTS instructor (
  instructor_id VARCHAR(45) NOT NULL,
   PRIMARY KEY (instructor_id),
   FOREIGN KEY (instructor_id) REFERENCES professor (professor_id));

CREATE TABLE IF NOT EXISTS teaches (
  instructor_id VARCHAR(45) NOT NULL,
  course_id INT NOT NULL,
   PRIMARY KEY (instructor_id, course_id),
   FOREIGN KEY (instructor_id) REFERENCES professor (professor_id),
   FOREIGN KEY (course_id) REFERENCES course (course_id)
 );
 
  CREATE TABLE IF NOT EXISTS TA (
  TA_id VARCHAR(45) NOT NULL,
   PRIMARY KEY (TA_id),
   FOREIGN KEY (TA_id) REFERENCES student (student_id));
   
CREATE TABLE IF NOT EXISTS assists (
  TA_id VARCHAR(45) NOT NULL,
  course_id INT NOT NULL,
   PRIMARY KEY (TA_id, course_id),
   FOREIGN KEY (TA_id) REFERENCES TA (TA_id),
   FOREIGN KEY (course_id) REFERENCES course (course_id)
 );
 
 CREATE TABLE IF NOT EXISTS pre_requisite (
  pre_requisite_id INT NOT NULL,
  course_id INT NOT NULL,
   PRIMARY KEY (pre_requisite_id, course_id),
   FOREIGN KEY (pre_requisite_id) REFERENCES course (course_id)
 );
 
 CREATE TABLE IF NOT EXISTS semester (
  TA_id VARCHAR(45) NOT NULL,
   course_id INT,
  season VARCHAR(45) NOT NULL,
  offers INT NOT NULL,
  year INT NOT NULL,
  instructor VARCHAR(45),
   PRIMARY KEY (season,offers,year,course_id),
   FOREIGN KEY (TA_id) REFERENCES TA (TA_id),
   FOREIGN KEY (course_id) REFERENCES course (course_id),
   FOREIGN KEY (offers) REFERENCES course(department_id),
   FOREIGN KEY (instructor) REFERENCES instructor (instructor_id)
 );
 
  CREATE TABLE IF NOT EXISTS register (
  student_id VARCHAR(45),
  course_id INT,
  season VARCHAR(45) NOT NULL,
  offers INT NOT NULL,
  instructor VARCHAR(45),
  year INT NOT NULL,
	PRIMARY KEY (season,course_id,student_id,instructor,year),
	FOREIGN KEY (season) REFERENCES semester (season),
	FOREIGN KEY (offers) REFERENCES semester (offers),
	FOREIGN KEY (student_id) REFERENCES student (student_id),
	FOREIGN KEY (instructor) REFERENCES semester (instructor),
	FOREIGN KEY (course_id) REFERENCES semester(course_id));
      
CREATE TABLE IF NOT EXISTS will (
 student_id VARCHAR(45),
  course_id INT,
  season VARCHAR(45) NOT NULL,
  offers INT NOT NULL,
  year INT NOT NULL,
  instructor VARCHAR(45),
   PRIMARY KEY (course_id, year,season,instructor,student_id),
   FOREIGN KEY (season) REFERENCES register (season),
   FOREIGN KEY (offers) REFERENCES register (offers),
   FOREIGN KEY (instructor) REFERENCES register (instructor),
   FOREIGN KEY (course_id) REFERENCES register (course_id)
   );
   
   CREATE TABLE IF NOT EXISTS enrolls (
	student_id VARCHAR(45) NOT NULL,
     course_id INT,
    course_grade VARCHAR(45) NOT NULL,
    season VARCHAR(45) NOT NULL,
   offers INT NOT NULL,
   year INT NOT NULL,
   instructor VARCHAR(45),
   FOREIGN KEY (student_id) REFERENCES register (student_id),
   PRIMARY KEY (course_id, year,season,instructor,student_id),
   FOREIGN KEY (season) REFERENCES will (season),
   FOREIGN KEY (offers) REFERENCES will (offers),
   FOREIGN KEY (instructor) REFERENCES will (instructor),
   FOREIGN KEY (course_id) REFERENCES will (course_id)
   ); 
   
CREATE TABLE IF NOT EXISTS feedback (
  TA_id VARCHAR(45) NOT NULL,
  instructor_id VARCHAR(45) NOT NULL,
  student_id VARCHAR(45) NOT NULL,
  course_id INT NOT NULL,
  instructor_feedback VARCHAR(145),
  TA_feedback VARCHAR(145),
   PRIMARY KEY (TA_id, course_id),
   FOREIGN KEY (TA_id) REFERENCES TA (TA_id),
   FOREIGN KEY (course_id) REFERENCES course (course_id),
   FOREIGN KEY (student_id) REFERENCES enrolls (student_id),
   FOREIGN KEY (instructor_id) REFERENCES instructor (instructor_id)
 );
 
  CREATE TABLE IF NOT EXISTS has_Exams (
  exam_id INT NOT NULL,
 student_id VARCHAR(45),
  scores INT,
  exam_letter_grade VARCHAR(4),
  PRIMARY KEY (student_id, exam_id),
   FOREIGN KEY (student_id) REFERENCES enrolls (student_id),
  FOREIGN KEY (exam_id) REFERENCES exam (exam_id)
  );
 
    CREATE TABLE IF NOT EXISTS library (
		id INT NOT NULL,
        libName VARCHAR(100) NOT NULL,
        location VARCHAR(100) NOT NULL,
        PRIMARY KEY (id)
   );
 
   CREATE TABLE IF NOT EXISTS books (
		id INT NOT NULL,
        isbn varchar(13) NOT NULL,
        title varchar(100) NOT NULL,
        price INT NOT NULL,
        pubDate INT NOT NULL,
        author varchar(100) NOT NULL,
        pageNum INT NOT NULL,
        libraryID INT NOT NULL,
        PRIMARY KEY (id),
        FOREIGN KEY (libraryID) REFERENCES library (id)
   );
   
   CREATE TABLE IF NOT EXISTS purchased (
		account_id VARCHAR(45) NOT NULL,
        book_id INT NOT NULL,
        library_id INT NOT NULL,
        due_date DATETIME NOT NULL,
        overdue BOOLEAN NOT NULL,
		FOREIGN KEY (book_id) REFERENCES books (id),
        FOREIGN KEY (library_id) REFERENCES library (id),
        FOREIGN KEY (account_id) REFERENCES user_account (email_id)
   );
 
 
   

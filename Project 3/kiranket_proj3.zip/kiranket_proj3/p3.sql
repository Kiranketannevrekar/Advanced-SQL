use tinyhub;
DELETE FROM tinyhub.user_account WHERE email_id='kiranket@buffalo.edu';
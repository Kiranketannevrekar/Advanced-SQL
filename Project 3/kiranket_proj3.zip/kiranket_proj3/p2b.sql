INSERT INTO tinyhub.user_account (email_id, display_name,password)
VALUES ('kiranket@buffalo.edu', 'kiranket','kiran123');

INSERT INTO tinyhub.user_account (email_id, display_name,password)
VALUES ('professor@buffalo.edu', 'cheng','prof123');

INSERT INTO tinyhub.user_account (email_id, display_name,password)
VALUES ('ta@buffalo.edu', 'ta','ta123');

INSERT INTO tinyhub.department (department_id,department_name)
VALUES (1,'CSE');

INSERT INTO tinyhub.student (student_id, department_id,course_id,semester_id)
VALUES ('kiranket@buffalo.edu',1,560,1);

INSERT INTO tinyhub.professor (professor_id,department_id,course_id)
VALUES ('professor@buffalo.edu',1,560);

INSERT INTO tinyhub.instructor (instructor_id)
VALUES ('professor@buffalo.edu');

INSERT INTO tinyhub.TA (TA_id)
VALUES ('ta@buffalo.edu');

INSERT INTO tinyhub.course (course_id,department_id, course_name,class_capacity)
VALUES (560,1,'CSE 560',80);

INSERT INTO tinyhub.semester (TA_id, course_id,season,offers,year,instructor)
VALUES ('ta@buffalo.edu',560,'2020 Fall',1,2020,'professor@buffalo.edu');

INSERT INTO tinyhub.register (student_id,course_id,season,offers,instructor,year)
VALUES ('kiranket@buffalo.edu',560,'2020 Fall',1,'professor@buffalo.edu',2020);




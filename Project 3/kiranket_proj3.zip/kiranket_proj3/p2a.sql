INSERT INTO tinyhub.user_account (email_id, display_name,password)
VALUES ('unregistered_student@buffalo.edu', 'un','un123');

INSERT INTO tinyhub.department (department_id,department_name)
VALUES (1,'CSE');

INSERT INTO tinyhub.professor (professor_id,department_id,course_id)
VALUES ('professor@buffalo.edu',1,560);

INSERT INTO tinyhub.instructor (instructor_id)
VALUES ('professor@buffalo.edu');

INSERT INTO tinyhub.TA (TA_id)
VALUES ('ta@buffalo.edu');

INSERT INTO tinyhub.course (course_id,department_id, course_name,class_capacity)
VALUES (560,1,'CSE 560',80);

INSERT INTO tinyhub.semester (TA_id, course_id,season,offers,year,instructor)
VALUES ('ta@buffalo.edu',560,'2020 Fall',1,2020,'professor@buffalo.edu');

INSERT INTO tinyhub.enrolls (student_id, course_id, course_grade, season, offers, year, instructor)
VALUES ('unregistered_student@buffalo.edu',560, 'A', '2020 Fall',1,2020,'professor@buffalo.edu');
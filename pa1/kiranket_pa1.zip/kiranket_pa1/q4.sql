select dept_emp.emp_no as emp, dept_manager.emp_no as mgr, dept_emp.from_date
from dept_emp INNER JOIN dept_manager ON dept_manager.dept_no = dept_emp.dept_no
where dept_emp.to_date =  '9999-01-01' and dept_manager.to_date = '9999-01-01'
order by dept_emp.emp_no;

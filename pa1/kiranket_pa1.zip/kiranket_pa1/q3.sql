select employees.last_name, salaries.salary, salaries.from_date, salaries.to_date
from employees INNER JOIN salaries ON employees.emp_no = salaries.emp_no
order by employees.last_name, salaries.from_date, salaries.to_date, salaries.salary;

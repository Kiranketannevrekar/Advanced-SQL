select emp_no,birth_date,gender from employees
order by birth_date, emp_no;

select * from employees
where gender = 'M'
order by emp_no;

select first_name, last_name
from actor
where first_name = 'Kenneth';

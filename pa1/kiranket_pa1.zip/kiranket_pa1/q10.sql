select film_1.title as film_1, film_2.title as film_2, film_1.length, film_1.rating
from film film_1, film film_2
where film_1.length = film_2.length and film_1.rating = film_2.rating and film_1.film_id > film_2.film_id;

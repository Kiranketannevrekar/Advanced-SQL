update customer set active = 0 where first_name = 'Maria' and last_name = 'Miller';
select email, active from customer where first_name = 'Maria' and last_name = 'Miller';
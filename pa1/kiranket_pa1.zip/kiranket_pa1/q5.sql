select departments.dept_name, count(dept_emp.emp_no) as noe
from dept_emp INNER JOIN departments ON dept_emp.dept_no = departments.dept_no
where dept_emp.to_date = '9999-01-01'
group by dept_emp.dept_no
HAVING count(dept_emp.emp_no)>20000
order by departments.dept_name;


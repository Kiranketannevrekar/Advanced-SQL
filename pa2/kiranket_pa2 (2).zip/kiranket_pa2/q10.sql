SELECT 	a.customer_id, 
		SUM(a.amount) AS total,
        COUNT(DISTINCT a.rental_id) AS n_rent 
FROM	(	SELECT * 
			FROM payment 
            WHERE rental_id IS NOT NULL
		) a
GROUP BY a.customer_id
HAVING 	SUM(a.amount) > 100 
;
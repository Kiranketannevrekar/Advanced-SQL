SELECT 	d.dept_name AS dept_name,
		COUNT(dm.emp_no) AS cnt
FROM 	(	SELECT * 
			FROM dept_manager
            WHERE to_date <> '9999-01-01') AS dm
LEFT JOIN departments d ON dm.dept_no = d.dept_no 
GROUP BY d.dept_name
HAVING COUNT(dm.emp_no) > 1
ORDER BY	d.dept_name ASC;
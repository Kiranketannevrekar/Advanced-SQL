SELECT dm.emp_no, d.dept_name
FROM dept_manager dm LEFT JOIN departments d ON dm.dept_no = d.dept_no
WHERE NOT EXISTS (SELECT 1
FROM dept_manager dm_inner
WHERE DATEDIFF(dm_inner.to_date, dm_inner.from_date) <  datediff(dm.to_date, dm.from_date)
AND dm_inner.dept_no = dm.dept_no);
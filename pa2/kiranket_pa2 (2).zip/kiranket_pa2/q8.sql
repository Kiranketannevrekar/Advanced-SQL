select p.rental_id, p.payment_id 
from payment p 
where p.amount < ALL (	select p_inner.amount 
						from payment p_inner 
						where p_inner.amount <> p.amount 
						) 
order by p.rental_id;
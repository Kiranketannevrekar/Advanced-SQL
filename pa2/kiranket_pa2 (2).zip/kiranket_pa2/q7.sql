SELECT 	DISTINCT CONCAT_WS(' ', a.first_name, a.last_name) AS actor_name,
		COUNT(DISTINCT fc.category_id) AS ncat    
FROM film_category fc
RIGHT JOIN film_actor fa ON fc.film_id = fa.film_id 
RIGHT JOIN actor a ON fa.actor_id = a.actor_id
GROUP BY CONCAT_WS(' ', a.first_name, a.last_name)
ORDER BY 1 ASC;
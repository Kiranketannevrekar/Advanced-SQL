select 	a.emp_no as emp_no, 
        round(((select count(si.salary) from salaries as si where si.to_date = '9999-01-01' 
														  and si.emp_no < 20000
                                                          and si.salary <= s.salary)-1)/(sii.total_count)*100, 4) as percentile
from (select * from dept_emp) as a
left join (select * from salaries) as s on 	a.emp_no = s.emp_no 
cross join (select count(salary)-1 as total_count from salaries where to_date = '9999-01-01' and emp_no < 20000) as sii on 1=1

where 	a.emp_no < 20000 
		and a.to_date = '9999-01-01'
        and s.to_date = '9999-01-01'
order by a.emp_no;
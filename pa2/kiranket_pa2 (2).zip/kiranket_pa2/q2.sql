select dept_name, title, count(title) as cnt from (select title, dept_no, dept_emp.to_date
from titles inner join dept_emp
on titles.emp_no = dept_emp.emp_no
where titles.to_date = '9999-01-01' and dept_emp.to_date = '9999-01-01') H
inner join 
departments
on departments.dept_no = H.dept_no
group by title, dept_name
order by dept_name, title;
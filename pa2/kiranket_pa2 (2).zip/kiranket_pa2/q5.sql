SELECT 	b.emp_no as emp_no,
		b.on_date as on_date,
        o_title,
        n_title,
        o_salary,
        n_salary
FROM (	SELECT 	sal1.salary as o_salary,
				sal2.salary as n_salary,
                sal1.to_date as on_date,
                sal1.emp_no 
		FROM salaries sal1, salaries sal2 
        WHERE 	sal1.salary > sal2.salary 
				AND sal1.to_date = sal2.from_date 
                AND sal1.emp_no = sal2.emp_no 
	  ) as a 
INNER JOIN
	(	SELECT 	titles1.emp_no,
				titles1.title as o_title,
                titles2.title as n_title,
                titles1.to_date as on_date 
		FROM titles titles1, titles titles2 
		WHERE	titles1.to_date = titles2.from_date 
				AND titles1.emp_no = titles2.emp_no 
	) as b
ON b.on_date = a.on_date AND b.emp_no = a.emp_no
ORDER BY b.emp_no asc;
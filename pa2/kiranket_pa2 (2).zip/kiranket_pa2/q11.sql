SELECT a.f1, a.f2, count(customer_id) as cnt
FROM 
(SELECT 	film_1.film_id as f1, 
		film_2.film_id as f2,
        film_1.customer_id
FROM
	(	SELECT 	r.customer_id,
				i.film_id,
                r.rental_date,
                i.inventory_id,
                i.store_id,
                (	select 	min(ri.rental_date)
					from rental ri
					join inventory ii on ri.inventory_id = ii.inventory_id
					where 	ri.customer_id = r.customer_id and
							ri.rental_date > r.rental_date and
                            ii.film_id <> i.film_id
				) as next_rental_date
		FROM rental AS r
		JOIN inventory AS i ON r.inventory_id = i.inventory_id
	) as film_1
INNER JOIN
	(	SELECT 	r.customer_id, i.film_id, r.rental_date, i.inventory_id, i.store_id,
				(	select 	max(ri.rental_date)
					from rental ri
					join inventory ii on ri.inventory_id = ii.inventory_id
					where 	ri.customer_id = r.customer_id and
							ri.rental_date < r.rental_date and
                            ii.film_id <> i.film_id
				) as previous_rental_date
		FROM rental AS r
		JOIN inventory AS i ON r.inventory_id = i.inventory_id
	) as film_2
ON 	film_1.film_id <> film_2.film_id
	and ( film_2.rental_date = film_1.next_rental_date and film_2.previous_rental_date = film_1.rental_date )
	and film_1.customer_id = film_2.customer_id
    and film_1.inventory_id <> film_2.inventory_id
) AS a
GROUP BY a.f1, a.f2
ORDER BY 	count(customer_id) desc,
			a.f1 asc,
            a.f2 asc
;
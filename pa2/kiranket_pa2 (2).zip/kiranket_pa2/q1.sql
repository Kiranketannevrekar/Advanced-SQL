select distinct H.emp_no as e1, J.emp_no as e2 from 
(	select employees.emp_no, s.salary 
	from employees 	inner join dept_emp on employees.emp_no = dept_emp.emp_no
					left join salaries s on employees.emp_no = s.emp_no and 
											s.to_date = '9999-01-01' and 
                                            dept_no = 'd002' and 
                                            year(birth_date) = '1956' and 
                                            dept_emp.to_date = '9999-01-01' and 
                                            employees.emp_no < 100000
) H inner join
(	select employees.emp_no, s.salary 
	from employees 	inner join dept_emp on employees.emp_no = dept_emp.emp_no
					left join salaries s on employees.emp_no = s.emp_no and 
											s.to_date = '9999-01-01' and 
                                            dept_no = 'd002' and 
                                            year(birth_date) = '1956' and 
                                            dept_emp.to_date = '9999-01-01'  and 
                                            employees.emp_no < 100000
) J
on H.emp_no > J.emp_no and
	H.salary < J.salary
order by H.emp_no, J.emp_no;
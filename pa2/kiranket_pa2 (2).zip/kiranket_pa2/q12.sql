select film_id, to_breakeven from (select * from (select bk.film_id,bk.breakeven as to_breakeven from 
(select f.film_id, r.rental_date, r.return_date, p.payment_date, f.rental_rate, 
f.rental_duration,f.replacement_cost,p.amount,
sum(amount) as total_earning,
(f.replacement_cost-sum(amount)) as breakeven
from film f, inventory i, rental r, payment p
where f.film_id = i.film_id and
i.inventory_id = r.inventory_id and 
r.rental_id = p.rental_id
group by f.film_id) as bk
where bk.breakeven > 0
order by bk.breakeven asc) as bk2 LIMIT 5,5) as bk3
order by film_id;
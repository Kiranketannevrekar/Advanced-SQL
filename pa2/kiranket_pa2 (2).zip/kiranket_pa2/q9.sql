select 	f.film_id,f.length,avg(datediff(r.return_date, r.rental_date)) as avg_days
from rental r
left join inventory i on r.inventory_id = i.inventory_id
left join film f on f.film_id = i.film_id
group by f.film_id
order by f.film_id;
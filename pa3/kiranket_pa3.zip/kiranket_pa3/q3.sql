WITH RECURSIVE multiply(m, n) AS (
(SELECT 1,1)
UNION ALL
(SELECT case when (n+1) > 9 then m+1 else m end,
case when (n+1) > 9 then 1 else n+1 end
FROM multiply
WHERE m < 9 or n < 9))
SELECT m,n, m*n 
FROM multiply;
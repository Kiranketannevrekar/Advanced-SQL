WITH RECURSIVE multiply AS (
(SELECT src,dst from amap)
union
(select multiply.src,amap.dst from amap,multiply where amap.src = multiply.dst))
SELECT * FROM multiply
order by src,dst;
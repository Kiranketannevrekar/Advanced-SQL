WITH  RECURSIVE promotion(p3,p4,avgYears) 
AS (
	SELECT 	t1 
			,t2
			,anchor.d1 AS d1 
    FROM (	SELECT 	n.t1 AS t1
					,n.t2 AS t2
					,AVG(n.d1) AS d1
			FROM (	SELECT  t1.title AS t1
							,t2.title AS t2
							,(YEAR(t2.from_date)-YEAR(t1.from_date)+1) AS d1 
					FROM employees.titles t1
					INNER JOIN	employees.titles t2  
					ON 	t1.emp_no=t2.emp_no 
						AND t1.to_date=t2.from_date 
					) n 
			GROUP BY n.t1,n.t2
		) anchor 
  UNION 
  
	SELECT  p1.p3 AS p3
			,recurssion.t2 AS t2
			,(p1.avgYears+recurssion.d2) AS d1 
	FROM (	SELECT 	v.t1 AS t1
					,v.t2 AS t2
					,avg(v.d2) AS d2 
			FROM(	SELECT  t1.title AS t1
							,t2.title AS t2
							,(YEAR(t2.from_date)-YEAR(t1.from_date)+1) AS d2 
					FROM employees.titles t1
					INNER JOIN	employees.titles t2  
					ON 	t1.emp_no=t2.emp_no 
						AND	t1.to_date=t2.from_date
				) v GROUP BY v.t1, v.t2
		) recurssion  
	INNER JOIN promotion p1 ON  recurssion.t1=p1.p4 
								AND p1.avgYears+recurssion.d2<100
	)
SELECT 	promotion.p3 AS src
		,promotion.p4 AS dst
		, MIN(promotion.avgYears) AS years 
FROM promotion 
WHERE promotion.p3!=promotion.p4 
GROUP BY promotion.p3, promotion.p4 
ORDER BY promotion.p3, promotion.p4;
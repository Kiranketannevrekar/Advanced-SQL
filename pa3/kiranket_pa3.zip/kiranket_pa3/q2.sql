WITH RECURSIVE q2(n, a, b) AS (
(select 0,0,0)
 UNION ALL
(SELECT n+1,
CASE
    WHEN n < 1 THEN n+1
    when n = 1 then a+b
    when n > 1 and a%2 != 0 then a+b
    when n > 1 and a%2 = 0 then a+b+1
end,
CASE
    WHEN n < 1 then b
    else a
end
FROM q2
where n < 10)
)
SELECT n,a as 'f(n)'
FROM q2;
WITH RECURSIVE 
V1 as(
SELECT c1.customer_id as c1, c2.customer_id as c2, 
	       ROUND(ST_Distance_Sphere(a1.location, a2.location) * .000621371192, 2) as loc 
	FROM customer c1, customer c2,
	     address a1, address a2 
	WHERE c1.address_id = a1.address_id 
	  AND c2.address_id = a2.address_id
	  AND c1.customer_id < c2.customer_id 
	  AND ST_X(a1.location) <= 180 AND ST_X(a2.location) <= 180
	  AND ST_X(a1.location) > -180 AND ST_X(a2.location) > -180
	  AND ST_Y(a1.location) <= 90 AND ST_Y(a2.location) <= 90
	  having loc < 20
	  AND loc > 0),

cluster(c1, c2, loc) AS (
    SELECT c1,c2,loc
	FROM V1
    UNION 
    SELECT 	V1.c1
			, V2.c2
            , V1.loc + V2.loc
    FROM V1, V1 as V2
    where V2.c1 = V1.c2
)

SELECT c1,c2,min(loc) as distance FROM cluster
where c1 not in (select c2 from cluster)
GROUP BY c1,c2
order by c1, c2;
WITH RECURSIVE amapRecursiveCTE as (

	SELECT 	src
			,dst
            ,cost
            ,0 as Iteration
    FROM amap
    
    UNION DISTINCT 
    
    SELECT 	arc.src
			, a.dst
            , a.cost + arc.cost
            , Iteration + 1
    FROM amap a INNER JOIN amapRecursiveCTE arc
	ON a.src = arc.dst
	WHERE Iteration < 1
)
SELECT src, dst, MIN(cost) as cost 
FROM amapRecursiveCTE where src != dst
GROUP BY src, dst
ORDER BY src
;
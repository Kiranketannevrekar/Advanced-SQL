
WITH RECURSIVE factorial(n,d,c,q) AS (
(SELECT 999,1,999,999/1)
UNION ALL
(SELECT 999, d+1, 999%(d+1), 999/(d+1)
FROM factorial
WHERE d < 999))
SELECT n,d,q 
FROM factorial
where c in (0,999);